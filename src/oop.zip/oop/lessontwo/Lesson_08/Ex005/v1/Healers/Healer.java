package oop.lessontwo.Lesson_08.Ex005.v1.Healers;

import oop.lessontwo.Lesson_08.Ex005.v1.Hero;

public abstract class Healer extends Hero {
    
    public void healing(Hero target) {
        
    }
}
